<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CryptoCoinsIco extends Model
{
    protected $fillable = ['id', 'name', 'alias', 'status', 'image', 'website', 'icowatchlist_url', 'start_time', 'end_time', 'timezone', 'description'];
}
