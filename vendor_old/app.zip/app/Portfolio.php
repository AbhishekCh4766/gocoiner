<?php

namespace App;

use App\Presenters\NewsPresenter;
use Illuminate\Database\Eloquent\Model;
use McCool\LaravelAutoPresenter\HasPresenter;

class Portfolio extends Model 
{

protected $table = 'portfolio';


}
