<div class="adsense-container container">
    <div class="row">
        <div class="col-lg-12">
            <ins class="adsbygoogle"
                 style="display:block"
                 data-ad-client="{{ $adsense_pub_id }}"
                 data-ad-slot="{{ $slot_id }}"
                 data-ad-format="auto">
            </ins>
            <script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
        </div>
    </div>
</div>