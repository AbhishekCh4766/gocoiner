<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HistoryJobQueue extends Model
{
    protected $fillable = ['symbol'];
}
