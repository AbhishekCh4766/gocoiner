<?php echo Form::open(['route' => 'admin.search', 'class' => 'pull-right col-sm-3', 'method' => 'GET']); ?>

<div class="input-group">
    <span class="input-group-addon"><i class="fa fa-search"></i></span>
    <?php echo Form::text('search_term', null, [ 'class' => 'form-control form-control-sm']); ?>

</div>
<?php echo Form::close(); ?>