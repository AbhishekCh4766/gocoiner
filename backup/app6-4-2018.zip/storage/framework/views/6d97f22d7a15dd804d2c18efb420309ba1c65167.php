<table class="tablesaw tablesaw-stack" data-tablesaw-mode="stack">
    <thead>
    <tr>
        <th data-tablesaw-sortable-col>Currency</th>
        <th data-tablesaw-sortable-col data-tablesaw-sortable-numeric>Price</th>
        <th data-tablesaw-sortable-col data-tablesaw-sortable-default-col data-tablesaw-sortable-numeric>Mkt. Cap</th>
        <th data-tablesaw-sortable-col data-tablesaw-sortable-numeric>Volume 24H</th>
        <th data-tablesaw-sortable-col data-tablesaw-sortable-numeric>Change % (1H)</th>
        <th data-tablesaw-sortable-col data-tablesaw-sortable-numeric>Change % (24H)</th>
        <th data-tablesaw-sortable-col data-tablesaw-sortable-numeric>Change % (7D)</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $coins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <span>
                    <?php if(isset($coin->logo)): ?>
                        <a href="<?php echo e(coin_url($coin)); ?>">
                            <img src="<?php echo e(asset('asset/images/coins/tn/' . $coin->logo)); ?>" width="18">
                        </a>
                    <?php endif; ?>
                </span>
                <strong>
                    <a href="<?php echo e(coin_url($coin)); ?>"> <?php echo e($coin->name); ?></a>
                </strong>
                &nbsp;
                <sup class="small-text"><?php echo e($coin->symbol); ?></sup>
            </td>
            <td><sup>$</sup> <?php echo e($coin->price_usd); ?></td>
            <td><sup>$</sup> <?php echo e($coin->market_cap_usd); ?></td>
            <td><sup>$</sup> <?php echo e($coin->volume_usd_24h); ?></td>
            <?php echo $__env->make('frontend.partials.change-td-no-label', ['value' => $coin->percent_change_1h, 'class' => ''], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('frontend.partials.change-td-no-label', ['value' => $coin->percent_change_24h, 'class' => ''], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('frontend.partials.change-td-no-label', ['value' => $coin->percent_change_7d, 'class' => ''], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>