

<?php $__env->startSection('title', 'Cryptocurrencies'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">

                <div class="m-l-20 m-r-20 m-t-5 m-b-5">
                    <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>

                <div class="card-block">
                    <h4 class="card-title">Pages</h4>
                    <a href="<?php echo e(route('admin.pages.custom')); ?>" class="btn btn-info btn-sm pull-right m-l-10"><i class="fa fa-plus-square-o"></i> Custom Page</a>
                    <a href="<?php echo e(route('admin.pages.create')); ?>" class="btn btn-success btn-sm pull-right"><i class="fa fa-plus-square-o"></i> Post</a>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                            <th>Title</th>
                            <th>Type</th>
                            <th class="text-right">Published</th>
                            <th class="text-right">Last Modified</th>
                            <th></th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(route('admin.pages.show', $page->id)); ?>" target="_blank"> <?php echo e($page->title); ?></a></td>
                                    <td> <?php echo e($page->type); ?></td>
                                    <td class="text-right"> <?php echo $page->active ? '<span class="text-success"><i class="fa fa-check"></i></span>' : '<span class="text-warning"><i class="fa fa-times"></i></span>'; ?></td>
                                    <td class="text-right"><?php echo e($page->last_updated); ?></td>
                                    <td class="text-right">
                                        <a class="btn btn-sm btn-secondary"
                                           href="<?php echo e(route('admin.pages.edit', $page->id)); ?>"><i class="fa fa-pencil-square-o"></i></a>

                                        <?php echo $__env->make('backend.partials.delete-link', ['url' => route('admin.pages.destroy', $page->id),  'form_id' => 'delete-page-' . $page->id], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <nav><?php echo $pages->appends(\Request::except('page'))->render('vendor.pagination.bootstrap-4'); ?></nav>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>