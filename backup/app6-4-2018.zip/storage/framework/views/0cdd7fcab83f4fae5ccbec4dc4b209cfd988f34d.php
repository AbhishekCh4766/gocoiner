

<?php $__env->startSection('title', 'Create Menu'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-block">
                    <h4 class="card-title">Create Menu</h4>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo Form::open(['class'=>'form', 'route' => 'admin.menus.store', 'method' => 'POST']); ?>


                    <?php echo $__env->make('backend.partials.input-text', ['id' => 'name', 'label' => 'Title', 'value' => old('name'), 'required' => true], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php echo $__env->make('backend.partials.input-select', ['id' => 'parent_id', 'label' => 'Parent Menu', 'selected' => old('parent_id'), 'required' => false, 'col' => 7, 'options' => $parents, 'placeholder' => 'Select Parent Menu...'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php echo $__env->make('backend.partials.input-text', ['id' => 'link', 'label' => 'Custom URL', 'value' => old('link'), 'required' => false], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php echo $__env->make('backend.partials.input-select', ['id' => 'page_id', 'label' => 'Linked Page', 'selected' => old('page_id'), 'required' => false, 'col' => 7, 'options' => $pages, 'placeholder' => 'Select linked page...'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php echo $__env->make('backend.partials.input-check', ['id' => 'active', 'label' => 'Publish?', 'value' => 'value', 'checked' => old('active'), 'required' => false], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <hr>

                    <a href="<?php echo e(route('admin.menus.index')); ?>" class="btn btn-lg btn-secondary">&larr; Back</a>

                    <?php echo Form::submit('Create', ['class' => 'btn btn-lg btn-success pull-right']); ?>


                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>