

<?php $__env->startSection('title', 'Search Results'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-block">

                    <div class="table-responsive">
                        <?php if(count($coins) == 0): ?>
                            <div class="aligncenter">
                                <p>No coins found.</p>
                            </div>
                        <?php else: ?>
                            <?php echo $__env->make('frontend.partials.table-plain', ['coins' => $coins], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <nav><?php echo $coins->appends(\Request::except('page'))->render('vendor.pagination.simple-bootstrap-4'); ?></nav>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>