<div class="row card-block">
    <label for="<?php echo e($id); ?>" class="col-<?php echo e($text_col ?? '4'); ?> col-form-label"><?php echo e($label); ?></label>
    <div class="col-<?php echo e($col ?? '2'); ?>">
        <?php echo Form::number($id, $value, ['class' => 'form-control', 'id' => $id, 'required' => $required, 'min' => $min, 'max' => $max]); ?>


        <?php if($errors->has($id)): ?>
            <div class="form-control-feedback">
                <strong><?php echo e($errors->first($id)); ?></strong>
            </div>
        <?php endif; ?>
    </div>
</div>