<table class="table stylish-table table-hover">
    <thead>
    <tr>
        <th colspan="2"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name', __('coin.currency')));?></th>
        <th class="text-right"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('price_usd', __('coin.price')));?></th>
        <th class="text-right"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('market_cap_usd', __('coin.market_cap')));?></th>
        <th class="text-right"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('volume_usd_24h', __('coin.volume_24h')));?></th>
        <th class="text-right"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('percent_change_1h', __('coin.change_1h')));?></th>
        <th class="text-right"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('percent_change_24h', __('coin.change_24h')));?></th>
        <th class="text-right"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('percent_change_7d', __('coin.change_7d')));?></th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $coins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="width:48px; padding-right: 6px;">
                <span>
                    <?php if(isset($coin->logo)): ?>
                        <a href="<?php echo e(coin_url($coin)); ?>">
                            <img src="<?php echo e(asset('asset/images/coins/tn/' . $coin->logo)); ?>" width="30">
                        </a>
                    <?php endif; ?>
                </span>
           </td>
       
            <td>
                <h6>
                    <a href="<?php echo e(coin_url($coin)); ?>" class="d-none d-md-block d-lg-block d-xl-block"> <?php echo e($coin->name); ?></a>
                </h6>
                <small class="text-muted"><?php echo e($coin->symbol); ?></small>
            </td>

            <td class="text-right"><sup>$</sup> <?php echo e($coin->price_usd); ?></td>
            <td class="text-right"><sup>$</sup> <?php echo e($coin->market_cap_usd); ?></td>
            <td class="text-right"><sup>$</sup> <?php echo e($coin->volume_usd_24h); ?></td>
            <?php echo $__env->make('frontend.partials.change-td', ['value' => $coin->percent_change_1h, 'class' => 'text-right'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('frontend.partials.change-td', ['value' => $coin->percent_change_24h, 'class' => 'text-right'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('frontend.partials.change-td', ['value' => $coin->percent_change_7d, 'class' => 'text-right'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<script>
    TablesawConfig = {
        swipeHorizontalThreshold: 2,
        swipeVerticalThreshold: 20
    };
</script>