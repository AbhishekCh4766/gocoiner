<div class="table-responsive">
    <table class="table table-hover">
        <thead>
        <th>Name</th>
        <th>Symbol</th>
        <th>Coin ID</th>
        <th class="text-right">Last Updated</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $coins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href="<?php echo e(route('admin.coins.edit', $coin->id)); ?>"> <?php echo e($coin->name); ?></a></td>
                <td> <?php echo e($coin->symbol); ?></td>
                <td> <?php echo e($coin->coin_id); ?></td>
                <td class="text-right"><?php echo e($coin->last_updated); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>