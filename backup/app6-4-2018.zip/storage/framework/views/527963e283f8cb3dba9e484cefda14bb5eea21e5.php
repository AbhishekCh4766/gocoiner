

<?php $__env->startSection('title', 'Cryptocurrencies'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-block">
                    <h4 class="card-title">Search Result For "<?php echo e($q); ?>"
                        <?php echo $__env->make('backend.partials.search-form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </h4>
                    <h6 class="card-subtitle">About <?php echo e(number_format($coins->total())); ?> results</h6>

                    <?php echo $__env->make('backend.partials.table', ['coins' => $coins], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <nav><?php echo $coins->appends(\Request::except('page'))->render('vendor.pagination.bootstrap-4'); ?></nav>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>