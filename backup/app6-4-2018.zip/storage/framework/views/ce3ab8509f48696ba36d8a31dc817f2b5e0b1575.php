<?php $__env->startSection('title', __('news.page_title')); ?>

<?php $__env->startSection('content'); ?>
<div class="main-news-page">
    <div class="row news-page">
        
        <form name="newsseach" action="<?php echo e(url('news')); ?>" action="get">
        <div class="col-6">
            <div class="form-group">

                <input type="text" class="form-controller" class="search_news" id="search_news" name="q" placeholder="Search for News"></input>

                <!-- <input type="submit" value="submit"> -->
            </div>
        </div>

    </form>

        <div class="col-12 news-bx">
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article>
                    <div class="card card-block-inr-main">
                        <div class="card-block">
							<div class="col-sm-3 tab-left-image-inr-page">
								<div class="tab-left-image-inr-bx">
									<img src="<?php echo e($data->image); ?>">
								</div>
								<div class="small-text">
									<i class="fa fa-calendar"></i>&nbsp;&nbsp;<?php echo e($data->published_on); ?>

								</div>
							</div>
							<div class="card-block-news-bx">
									 <h4 class="card-title">
									<a href="<?php echo e($data->url); ?>" rel="nofollow"
									   target="_blank"><?php echo e($data->title); ?></a>
								</h4>
								
							</div>
							
							<div class="col-sm-9">
							
								<p><?php echo e($data->body); ?></p>
							</div>
							
							<div class="bottom-article">
								<a href="<?php echo e($data->url); ?>" rel="nofollow" target="_blank"
								   class="pull-right btn btn-sm btn-rounded btn-outline-primary"><?php echo e(__('news.read_more')); ?>

									<i class="fa fa-angle-right"></i></a>
							</div>
							
                        </div>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
        </div>
    </div>
<div class="pagination-div" style="text-align: center;">
           <?php echo $news->links(); ?>

 </div>

<?php $__env->stopSection(); ?>

 </div>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>