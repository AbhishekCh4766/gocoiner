<a href="<?php echo e($url); ?>"
   class="btn btn-sm btn-danger"
   onclick="event.preventDefault();
           if (confirm('Are You Sure to delete this?')) {
               document.getElementById('<?php echo e($form_id); ?>').submit();
           }">
    <i class="fa fa-trash"></i>
</a>

<form id="<?php echo e($form_id); ?>" action="<?php echo e($url); ?>" method="POST" style="display: none;">
    <?php echo e(method_field('DELETE')); ?>

    <?php echo e(csrf_field()); ?>

</form>