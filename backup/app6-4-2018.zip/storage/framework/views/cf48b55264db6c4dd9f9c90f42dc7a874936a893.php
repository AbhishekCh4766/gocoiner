

<?php $__env->startSection('title', 'Settings'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-9 col-xlg-10 col-md-8">
            <div class="card">

                <div class="m-l-20 m-r-20 m-t-5 m-b-5">
                    <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>

                <ul class="nav nav-tabs profile-tab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#general" role="tab">General</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#seo" role="tab">SEO</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#customization" role="tab">Customization</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#monetization" role="tab">Monetization</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#system" role="tab">System</a>
                    </li>
                </ul>


                <div class="tab-content">
                    <div class="tab-pane active" id="general" role="tabpanel">
                        <?php echo $__env->make('backend.settings.tab-general', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>

                    <div class="tab-pane" id="seo" role="tabpanel">
                        <?php echo $__env->make('backend.settings.tab-seo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>

                    <div class="tab-pane" id="customization" role="tabpanel">
                        <?php echo $__env->make('backend.settings.tab-customization', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>

                    <div class="tab-pane" id="monetization" role="tabpanel">
                        <?php echo $__env->make('backend.settings.tab-monetization', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>

                    <div class="tab-pane" id="system" role="tabpanel">
                        <?php echo $__env->make('backend.settings.tab-system', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>

                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-styles'); ?>
    <style>
        .card-block {
            padding-top: 8px !important;
            padding-bottom: 8px !important;
        }
    </style>
    <?php echo Html::style('asset/vendor/icheck/skins/square/blue.css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <?php echo Html::script('asset/vendor/icheck/icheck.min.js'); ?>

    <script>
        $(document).ready(function () {
            $('.check').iCheck({
                checkboxClass: 'icheckbox_square-blue',
                radioClass: 'iradio_square-blue',
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>