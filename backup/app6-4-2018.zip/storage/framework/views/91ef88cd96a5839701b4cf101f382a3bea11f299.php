<?php $__env->startSection('title', $Press_release->title); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <article>
                <div class="card">
                    <div class="card-block">
                        <h4 class="card-title">
                            <?php echo e($Press_release->title); ?>

                        </h4>
                        <div class="small-text">
                            <i class="fa fa-calendar"></i>&nbsp;&nbsp;<?php echo e($Press_release->last_updated); ?>

                        </div>
                        <?php echo $Press_release->content; ?>

                    </div>
                </div>
            </article>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>