<aside class="left-sidebar">
    
    <div class="scroll-sidebar">

</div>
        
       <!--  <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <li>
                    <a href="<?php echo e(route('home.market')); ?>" aria-expanded="false"><span class="hide-menu"><?php echo e(__('home.market')); ?></span></a>
                </li>
                <?php if(auth()->guard()->check()): ?>
                    <li>
                        <a href="<?php echo e(route('admin.index')); ?>"> <?php echo e(__('home.admin')); ?></a>
                    </li>
                <?php endif; ?>
                <li><a href="<?php echo e(route('news.index')); ?>"> <?php echo e(__('news.news')); ?></a></li>
                <?php if($has_blog_posts): ?>
                    <li><a href="<?php echo e(route('pages.index')); ?>"> <?php echo e(__('home.blog')); ?></a></li>
                <?php endif; ?> -->

         <!--        <?php $__currentLoopData = $custom_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_id => $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a class="has-arrow " href="<?php echo e($attr['url']); ?>" aria-expanded="false"><span
                                    class="hide-menu"> <?php echo e($attr['title']); ?></span></a>
                        <?php if(Menu::exists($menu_id)): ?>
                            <?php echo Menu::get($menu_id)->asUl(['class' => 'collapse',  'aria-expanded' => 'false']); ?>

                        <?php endif; ?>
                    </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
       
          <!--       <li>
                    <a class="has-arrow " href="#" aria-expanded="false"><span class="hide-menu"><?php echo e(__('home.site')); ?></span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="<?php echo e(route('contact.index')); ?>"> <?php echo e(__('home.contact')); ?></a></li>
                        <li><a href="<?php echo e(route('static.terms')); ?>"> <?php echo e(__('home.terms')); ?></a></li>
                        <li><a href="<?php echo e(route('static.privacy')); ?>"> <?php echo e(__('home.privacy')); ?></a></li>
                        <li><a href="<?php echo e(route('static.disclaimer')); ?>"> <?php echo e(__('home.disclaimer')); ?></a></li>
                        <li><a href="<?php echo e(route('sitemap.index')); ?>"> <?php echo e(__('home.sitemap')); ?></a></li>
                        <?php if(auth()->guard()->guest()): ?>
                            <li><a href="<?php echo e(route('admin.index')); ?>"> <?php echo e(__('home.admin')); ?></a></li>
                        <?php endif; ?>
                    </ul>
                </li>
            </ul>
        </nav> 

    </div> -->

 </aside> 

