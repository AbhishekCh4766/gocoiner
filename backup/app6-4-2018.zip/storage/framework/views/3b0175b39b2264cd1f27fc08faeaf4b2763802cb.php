<?php $__env->startSection('title', \App\Library\SeoHelper::title()); ?>

<?php $__env->startSection('content'); ?>


<div class="container thermogram-container">

  <div class="row">
      <div class="inr-thermogram">
      	<?php $__currentLoopData = $coins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 single-thermogram" >
		  	<?php if($coin->percent_change_24h <= 0): ?>
			<div class="inr-thermogram-bx">
			<?php else: ?>	
            <div class="inr-thermogram-bx color-green-bx">

            	<?php endif; ?>

			  <div class="thermogram-star-bx">
			  	<a href="<?php echo e(coin_url($coin)); ?>"> 
			  <p><?php echo e($coin->name); ?></p> <span><a href="#"><i class="fa fa-star-o" aria-hidden="true"></i></a></span>
			  </div>
			  <div class="thermogram-star-bx-inr">
			  <a href="#">
			  <div class="thermogram-star-btv-bx">
			 <!--  <p>1</p> -->
			  <h3><?php echo e($coin->symbol); ?> </h3>
			  <h4><?php echo e($coin->percent_change_24h); ?>%</h4>
			   </div>
			   
			   <div class="thermogram-star-btv-bottom">
			   <h4>$<?php echo e($coin->price_usd); ?> </h4>
			   <p><span>Vol: </span>$<?php echo e($coin->volume_usd_24h); ?>  B</p>
			   <p><span>Cap: </span>$<?php echo e($coin->market_cap_usd); ?> B</p>
			   
			   </div>
			  
			  
			  </a>
			 
			  </div>
			  

			</div>
			
		  </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<!-- 	    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
			<div class="inr-thermogram-bx color-green-bx">
			  <div class="thermogram-star-bx">
			  <p>Ethereum</p> <span><a href="#"><i class="fa fa-star-o" aria-hidden="true"></i></a></span>
			  </div>
			  <div class="thermogram-star-bx-inr">
			  <a href="#">
			  <div class="thermogram-star-btv-bx">
			  <p>2</p>
			  <h3>ETH</h3>
			  <h4>1.28%</h4>
			   </div>
			   
			   <div class="thermogram-star-btv-bottom">
			   <h4>$406.20</h4>
			   <p><span>Vol: </span>$1.25 B</p>
			   <p><span>Cap: </span>$40.05 B</p>
			   
			   </div>
			  
			  
			  </a>
			  </div>
			</div>
		  </div>


		
	  </div>   -->
<div class="pagination-div" style="text-align: center;">
           <?php echo $coins->links(); ?>

 </div>
  </div>  

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>