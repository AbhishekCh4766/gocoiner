<?php $__env->startSection('title', \App\Library\SeoHelper::title($coin)); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="row">
            <div class="col-lg-12 inner-market-coin-upper-section">
                <div class="card">
                    <div class="card-block">

                        <div class="d-flex flex-row">
                            <div class="img-width"><img src="<?php echo e(asset('asset/images/coins/img/'. $coin->logo)); ?>"
                                               class="img-rounded"
                                               height="80"></div>
                            <div class="p-l-20">
                                <h1 class="font-medium small-heading"><?php echo e($coin->name); ?> <sup><?php echo e($coin->symbol); ?></sup> <?php echo e(__('coin.h1')); ?></h1>
                                <p><?php echo e(\App\Library\SeoHelper::metaDescription($coin)); ?></p>
                               <!--  <?php if(isset($has_affiliate_links)): ?>
                                    <div class="pull-right">
                                        <a href="<?php echo e(\App\Library\Helper::randomAffiliateLink()); ?>" target="_blank"
                                           rel="nofollow">
                                            <button class="btn btn-danger" type="button">
                                                <span class="btn-label">
                                                    <i class="fa fa-shopping-cart"></i>
                                                </span>
                                                <?php echo e(__('coin.affiliate_link', ['coin_name' => $coin->name])); ?>

                                            </button>
                                        </a>
                                    </div>
                                <?php endif; ?> -->
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <?php if(isset($adsense_pub_id) && isset($adsense_slot1_id)): ?>
            <?php echo $__env->make('frontend.partials.adsense', ['slot_id' => $adsense_slot1_id], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>

        <div class="row graph-coin-section">
            <?php echo $__env->make('frontend.partials.coin_widget', ['col_size' => 3, 'title' => __('coin.price'), 'subtitle' => 'USD', 'price' => $coin->price_usd, 'footer' => (isset($coin->price_btc) && $coin->price_btc != 1) ? $coin->price_btc : '', 'footer_sub' => 'BTC'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('frontend.partials.coin_widget', ['col_size' => 3, 'title' => __('coin.market_cap'), 'subtitle' => 'USD', 'price' => $coin->market_cap_usd, 'footer' => null, 'footer_sub' => null], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('frontend.partials.coin_widget', ['col_size' => 3, 'title' => __('coin.change_1h'), 'subtitle' => '%', 'price' => \App\Library\Helper::arrowSignal($coin->percent_change_1h), 'footer' => null, 'footer_sub' => null], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('frontend.partials.coin_widget', ['col_size' => 3, 'title' => __('coin.change_24h'), 'subtitle' => '%', 'price' => \App\Library\Helper::arrowSignal($coin->percent_change_24h), 'footer' => null, 'footer_sub' => null], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="col-lg-12 market-innercoin">
                <div class="card">
                    <div class="card-block">
                        <h4 class="card-title text-center"><?php echo e(__('coin.historical_chart', ['coin_name' => $coin->name, 'coin_symbol' => $coin->symbol])); ?></h4>
                        <div style="background: url(<?php echo e(asset('asset/images/coins/img/' . $coin->logo)); ?>) no-repeat center center; position: absolute; height: 100%; width: 100%; opacity: 0.15;"></div>

                        <div class="btn-group" role="group" id="ranges">
                            <button data-range='7' type="button"
                                    class="btn btn-sm btn-info"> <?php echo e(__('coin.7d')); ?></button>
                            <button data-range='30' type="button"
                                    class="btn btn-sm btn-secondary"> <?php echo e(__('coin.1m')); ?></button>
                            <button data-range='60' type="button"
                                    class="btn btn-sm btn-secondary"> <?php echo e(__('coin.2m')); ?></button>
                            <button data-range='90' type="button"
                                    class="btn btn-sm btn-secondary"> <?php echo e(__('coin.3m')); ?></button>
                            <button data-range='180' type="button"
                                    class="btn btn-sm btn-secondary"> <?php echo e(__('coin.6m')); ?></button>
                            <button data-range='365' type="button"
                                    class="btn btn-sm btn-secondary"> <?php echo e(__('coin.1y')); ?></button>
                            <button data-range='1000' type="button"
                                    class="btn btn-sm btn-secondary"> <?php echo e(__('coin.all')); ?></button>
                        </div>

                        <div id="price_chart" style="height: 400px;"></div>
                        <div id="volume_chart" style="height: 200px;"></div>

                    </div>
                </div>

                <?php if(isset($adsense_pub_id, $adsense_slot2_id)): ?>
                    <?php echo $__env->make('frontend.partials.adsense', ['slot_id' => $adsense_slot2_id], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>

                <div class="card">
                    <div class="card-block p-b-0">
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs customtab" role="tablist">
                            <?php if(!blank($coin->description)): ?>
                                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#info"
                                                        role="tab"><span
                                                class="hidden-sm-up"><i class="ti-home"></i></span> <span
                                                class="hidden-xs-down"><?php echo e(__('coin.info')); ?></span></a></li>
                            <?php endif; ?>
                            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#tab-kfi"
                                                    role="tab"><span
                                            class="hidden-sm-up"><i class="ti-dashboard"></i></span> <span
                                            class="hidden-xs-down"><?php echo e(__('coin.kfi')); ?></span></a></li>
                            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#tab_hx" role="tab"><span
                                            class="hidden-sm-up"><i class="ti-bar-chart"></i></span> <span
                                            class="hidden-xs-down"><?php echo e(__('coin.hist_data')); ?></span></a></li>
                        </ul>
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <?php if(!blank($coin->description)): ?>
                                <div class="tab-pane active" id="info" role="tabpanel">
                                    <div class="p-20">
                                        <h3><?php echo e(__('coin.description')); ?></h3>
                                        <?php echo app('Indal\Markdown\Parser')->parse($coin->description); ?>

                                        <?php if(!blank($coin->start_date)): ?>
                                            <p><?php echo e(__('coin.gen_date')); ?>: <?php echo e($coin->start_date); ?></p>
                                        <?php endif; ?>
                                        <?php if(!blank($coin->website)): ?>
                                            <p><?php echo e(__('coin.website')); ?>: <a href="<?php echo e($coin->website); ?>"
                                                                            target="_blank"><?php echo e($coin->website); ?></a></p>
                                        <?php endif; ?>
                                    </div>
                                    <?php if(!blank($coin->features)): ?>
                                        <div class="p-20">
                                            <h3><?php echo e(__('coin.features')); ?></h3>
                                            <?php echo app('Indal\Markdown\Parser')->parse($coin->features); ?>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(!blank($coin->technology)): ?>
                                        <div class="p-20">
                                            <h3><?php echo e(__('coin.technology')); ?></h3>
                                            <?php echo app('Indal\Markdown\Parser')->parse($coin->technology); ?>
                                        </div>
                                    <?php endif; ?>

                                </div>
                            <?php endif; ?>

                            <div class="tab-pane p-20" role="tabpanel" id="tab-kfi">
                                <div class="table-responsive kfi-table">
                                    <table class="table table-condensed">
                                        <?php $__currentLoopData = array_chunk($table_rows, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td><strong><?php echo e($row[0]); ?></strong></td>
                                                    <td class="text-right"><?php echo $row[1]; ?></td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>

                            <div class="tab-pane p-20 <?php if(blank($coin->description)): ?> active <?php endif; ?>" id="tab_hx"
                                 role="tabpanel">
                                <div class="table-responsive m-t-40">
                                    <table id="historical-data" class="table table-bordered" data-page-length='10'>
                                        <thead>
                                        <tr>
                                            <th><?php echo e(__('system.date')); ?></th>
                                            <th><?php echo e(__('coin.price')); ?></th>
                                            <th><?php echo e(__('coin.volume')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php if($disqus_enabled): ?>
                        <div class="card-block p-b-0">
                            <?php echo $__env->make('frontend.partials.disqus', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                    <?php endif; ?>

                </div>

            </div>
        </div>
    </div>

    <script type="text/javascript">
        var AJAX_URL = "<?php echo e(route('api.history')); ?>";
        var SYMBOL = "<?php echo e($coin->symbol); ?>";
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-styles'); ?>
    <link href="<?php echo e(asset('asset/vendor/morrisjs/morris.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script src="<?php echo e(asset('asset/vendor/raphael/raphael-min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/vendor/morrisjs/morris.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/chart.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>