<table class="table table-hover">
    <thead>
    <th>Name</th>
    <th>Active</th>
    <th>Target</th>
    <th></th>
    </thead>
    <tbody>
    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td> <?php echo e($menu->name); ?></td>
            <td> <?php echo $menu->active ? '<span class="text-success"><i class="fa fa-check"></i></span>' : '<span class="text-warning"><i class="fa fa-times"></i></span>'; ?></td>
            <td> <?php echo e($menu->menuTarget); ?></td>
            <td class="text-right">
                <a class="btn btn-sm btn-secondary"
                   href="<?php echo e(route('admin.menus.edit', $menu->id)); ?>"><i class="fa fa-pencil-square-o"></i></a>

                <?php echo $__env->make('backend.partials.delete-link', ['url' => route('admin.menus.destroy', $menu->id), 'id' => $menu->id,  'form_id' => 'delete-menu-' . $menu->id], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>