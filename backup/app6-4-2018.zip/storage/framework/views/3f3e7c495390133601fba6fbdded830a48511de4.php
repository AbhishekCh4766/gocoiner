<?php $__env->startSection('title', \App\Library\SeoHelper::title()); ?>

<?php $__env->startSection('content'); ?>
<body>

<?php echo e(Form::open(array('url' => '/registration_page'))); ?>


    <ul class="errors">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

<center>

  <div class="row">
            <div class="registration-box">
               <h1>Registration Form</h1> 
            <div class="form-group">
              <?php echo e(Form::label('username', 'Username', array('class' => 'col-lg-12 control-label'))); ?> 
              <div class="col-lg-12">
                <?php echo e(Form::text('username', $username = null, array('class' => 'form-control input-md', 'placeholder' => 'Username', 'required' => 'true'))); ?>

              </div>
            </div>

            <div class="form-group">
              <?php echo e(Form::label('email', 'Email', array('class' => 'col-lg-12 control-label'))); ?>

              <div class="col-lg-12">
               <?php echo e(Form::email('email', $value = null, array('class' => 'form-control input-md', 'placeholder' => 'abc@gmail.com', 'required' => 'true'))); ?> 
              </div>

            </div>

            <div class="form-group">
              <?php echo e(Form::label('password', 'Password', array('class' => 'col-lg-12 control-label'))); ?>

              <div class="col-lg-12">
                <?php echo e(Form::password('password', array('class' => 'form-control input-md', 'placeholder' => 'at least 6 characters', 'required' => 'true|min:6'))); ?>

                <!-- <span class="help-block">at least 6 characters</span> -->
              </div>
            </div>

          <!--   <div class="form-group">
              <?php echo e(Form::label('password_confirmation', 'Confirm Password', array('class' => 'col-md-4 control-label text-right'))); ?>

              <div class="col-lg-12">
                <?php echo e(Form::password('password_confirmation', array('class' => 'form-control input-md', 'placeholder' => 'Confirm Password', 'required' => 'true|min:6'))); ?>

                <span class="help-block">at least 6 characters</span>
              </div>
            </div> -->

            <div class="col-lg-12">
                 <span class="help-block">By registering you agree to our Terms of Use and Privacy Policy</span>
                <?php echo e(Form::submit('Register', array('class' => 'btn btn-primary'))); ?>

              </div>
               </div>
<?php echo e(Form::close()); ?>


</center>
</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>