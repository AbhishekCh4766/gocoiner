<?php $__env->startSection('title', \App\Library\SeoHelper::title()); ?>

<?php $__env->startSection('content'); ?>

 <section id="wrapper">
        <div class="login-box card">
            <div class="card-block">

                <form class="form-horizontal form-material" id="loginform" method="POST"
                      action="<?php echo e(route('auth.post_login')); ?>">
                    <?php echo e(csrf_field()); ?>


                    <h3 class="box-title m-b-20">Sign In</h3>

                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <label for="email" class="col-xs-4 control-label">E-Mail Address</label>

                        <div class="col-xs-6">
                            <input id="email" type="email" class="form-control" name="email"
                                   value="<?php echo e(old('email')); ?>" required autofocus>

                            <?php if($errors->has('email')): ?>
                                <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <label for="password" class="col-xs-4 control-label">Password</label>

                        <div class="col-xs-6">
                            <input id="password" type="password" class="form-control" name="password" required>

                            <?php if($errors->has('password')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-md-12">
                            <div class="checkbox checkbox-primary pull-left p-t-0">
                                <input id="checkbox-signup" type="checkbox"
                                       name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                <label for="checkbox-signup">
                                    Remember me
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-xs-12">
                            <button type="submit" class="btn btn-info btn-lg btn-block">
                                Login
                            </button>
                            <a class="btn btn-link pull-right" href="<?php echo e(route('auth.password.request')); ?>">
                                Forgot Your Password?
                            </a>
                        </div>
                    </div>
                    <?php if(Route::has('auth.register')): ?>
                        <div class="form-group m-b-0">
                            <div class="col-sm-12 text-center">
                                <p>Don't have an account? <a href="<?php echo e(route('auth.register')); ?>"
                                                             class="text-info m-l-5"><b>Sign
                                            Up</b></a></p>
                            </div>
                        </div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>