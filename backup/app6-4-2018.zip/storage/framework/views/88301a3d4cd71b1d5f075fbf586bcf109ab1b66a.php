<table class="table table-hover">
    <thead>
    <th>Currency</th>
    <th class="text-right">Price</th>
    <th class="text-right">Market Cap</th>
    <th class="text-right">Volume 24H</th>
    <th class="text-right d-none d-md-block d-lg-block d-xl-block">Change % (1H)</th>
    <th class="text-right">Change % (24H)</th>
    <th class="text-right d-none d-md-block d-lg-block d-xl-block">Change % (7D)</th>
    </thead>
    <tbody>
    <?php $__currentLoopData = $coins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php if($coin->logo == ''): ?>
                <img src="<?php echo e(asset('asset/images/coins/tn/coin.png')); ?>" alt="Coin Image"/><a href="<?php echo e(coin_url($coin)); ?>"> <?php echo e($coin->name); ?></a>
                <?php else: ?>
                <img src="<?php echo e(asset('asset/images/coins/tn').'/'.$coin->logo); ?>" alt="Coin Image"/><a href="<?php echo e(coin_url($coin)); ?>"> <?php echo e($coin->name); ?></a>
                <?php endif; ?>
            </td>
            <td class="text-right"><sup>$</sup> <?php echo e($coin->price_usd); ?></td>
            <td class="text-right"><sup>$</sup> <?php echo e($coin->market_cap_usd); ?></td>
            <td class="text-right"><sup>$</sup> <?php echo e($coin->volume_usd_24h); ?></td>
            <?php echo $__env->make('frontend.partials.change-td', ['value' => $coin->percent_change_1h, 'class' => 'text-right d-none d-md-block d-lg-block d-xl-block'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('frontend.partials.change-td', ['value' => $coin->percent_change_24h, 'class' => 'text-right'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('frontend.partials.change-td', ['value' => $coin->percent_change_7d, 'class' => 'text-right d-none d-md-block d-lg-block d-xl-block'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>