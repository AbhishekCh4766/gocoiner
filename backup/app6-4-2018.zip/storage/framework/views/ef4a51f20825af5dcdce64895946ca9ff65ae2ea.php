<div class="p-l-20 p-t-10">
    <h3>Styling and Javascript Customizations
        <span class="small-text text-muted pull-right p-r-10"><a href="http://docs.kaijuscripts.com/coinindex/"
                                                                 target="_blank"><i class="fa fa-external-link"></i> Online Documentation</a></span>
    </h3>
    <p>Paste custom stylesheet and javascript code to include in each page.</p>
</div>

<?php echo Form::open(['class'=>'form', 'route' => 'admin.settings_customization', 'method' => 'POST']); ?>


<?php echo $__env->make('backend.partials.input-textarea', ['id' => 'CUSTOM_CSS', 'label' => 'Custom Styles', 'rows' => 10, 'col' => 8, 'text_col' => 3, 'value' => setting('CUSTOM_CSS'), 'required' => false], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('backend.partials.input-textarea', ['id' => 'CUSTOM_JS', 'label' => 'Custom Javascript', 'rows' => 10, 'col' => 8, 'text_col' => 3, 'value' => setting('CUSTOM_JS'), 'required' => false], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<hr>

<?php echo Form::submit('Save', ['class' => 'btn btn-lg btn-success m-l-20 m-b-20']); ?>


<?php echo Form::close(); ?>