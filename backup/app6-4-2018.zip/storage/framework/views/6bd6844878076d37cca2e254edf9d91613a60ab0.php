<div class="col-lg-3 col-md-<?php echo e($col_size); ?>">
    <div class="card">
        <div class="card-block">
            <h4 class="card-title"><?php echo e($title); ?></h4>
            <?php if(strlen($footer) > 0): ?>
                <div class="pull-left small-text">
                    <span class="text-muted"><sup><?php echo e($footer_sub); ?></sup> <?php echo e($footer); ?></span>
                </div>
            <?php endif; ?>
            <div class="text-right">
                <?php if(strlen($subtitle) > 0): ?>
                    <span class="text-muted"><?php echo e($subtitle); ?></span>
                <?php endif; ?>
                <p class="font-price font-light"><?php echo $price; ?></p>
            </div>
        </div>
    </div>
</div>