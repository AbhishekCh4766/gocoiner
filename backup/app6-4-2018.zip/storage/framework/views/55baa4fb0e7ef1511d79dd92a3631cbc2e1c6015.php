<div class="row card-block">
    <label for="<?php echo e($id); ?>" class="col-7 col-form-label">
        <?php echo Form::checkbox($id, $value, $checked, ['class' => 'check']); ?>

        &nbsp;<?php echo e($label); ?>

    </label>
</div>