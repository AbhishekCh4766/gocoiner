<?php $__env->startSection('title', __('Press_Release')); ?>

<?php $__env->startSection('content'); ?>


  <div class="prress-section">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-11 press-release">
                    <h3>PRESS RELEASE</h3>
                    <?php $__currentLoopData = $press_release; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Press): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row press-release-inner">
                         <div class="col-xs-12 col-sm-2">
                                  
                             <img src="<?php echo e(asset('public/images/press_release').'/' . $Press->pic); ?>" width="">
                        </div>
                        <div class="col-xs-12 col-sm-10">
                            <h5><?php echo e($Press->title); ?></h5>
                            <p><?php echo strip_tags($Press->content); ?> </p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
               </div>
             </div>
         </div>
         <?php echo $press_release->links(); ?>

     </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>