<div class="row card-block">
    <label for="<?php echo e($id); ?>" class="col-<?php echo e($text_col ?? '4'); ?> col-form-label"><?php echo e($label); ?></label>
    <div class="col-<?php echo e($col ?? '7'); ?>">
        <?php echo Form::select($id, $options, $selected, ['class' => 'custom-select col-' . $col ?? '7', 'placeholder' => $placeholder ?? 'Select an option...']); ?>


        <?php if($errors->has($id)): ?>
            <div class="form-control-feedback">
                <strong><?php echo e($errors->first($id)); ?></strong>
            </div>
        <?php endif; ?>
    </div>
</div>