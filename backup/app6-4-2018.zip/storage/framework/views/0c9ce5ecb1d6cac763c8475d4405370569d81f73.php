<td class="no-wrap <?php echo e($class); ?>">
    <?php if($value > 0): ?>
        <span class="change-up">
                <i class="fa fa-arrow-up"></i> <?php echo e($value); ?>%</span>
    <?php elseif($value < 0): ?>
        <span class="change-down">
                <i class="fa fa-arrow-down"></i> <?php echo e($value); ?>%</span>
    <?php endif; ?>
</td>