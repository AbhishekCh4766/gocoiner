

<?php $__env->startSection('title', 'Cryptocurrencies'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">

                <div class="m-l-20 m-r-20 m-t-5 m-b-5">
                    <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>

                <div class="card-block">
                    <h4 class="card-title">Menus</h4>
                    <a href="<?php echo e(route('admin.menus.create')); ?>" class="btn btn-success btn-sm pull-right m-l-10">
                        <i class="fa fa-plus-square-o"></i> New Menu
                    </a>
                    <div class="table-responsive">
                        <?php echo $__env->make('backend.menus.partials.table-menus', ['menus' => $menus], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>

                    <nav><?php echo $menus->appends(\Request::except('page'))->render('vendor.pagination.bootstrap-4'); ?></nav>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>