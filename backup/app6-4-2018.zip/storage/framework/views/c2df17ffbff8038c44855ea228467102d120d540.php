

<?php $__env->startSection('title', 'Translations'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-9 col-xlg-10 col-md-8">
            <div class="card">

                <div class="m-l-20 m-r-20 m-t-5 m-b-5">
                    <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>

                <div class="p-l-20 p-t-10">
                    <h3>Edit Translation Groups
                        <span class="small-text text-muted pull-right p-r-10"><a
                                    href="http://docs.kaijuscripts.com/coinindex/"
                                    target="_blank"><i class="fa fa-external-link"></i> Online Documentation</a></span>
                    </h3>
                </div>
                <div class="table-responsive m-10 p-20">
                    <table class="table table-bordered">
                        <thead>
                        <th>Language Groups</th>
                        <th class="text-right">
                            <a href="<?php echo e(route('admin.lang.reseed')); ?>"
                               class="btn btn-sm btn-danger"><i class="fa fa-recycle"></i> Reset All</a>
                        </th>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_ => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(title_case( $group->group )); ?></td>
                                <td class="text-right">
                                    <a href="<?php echo e(route('admin.lang.edit', $group->group)); ?>"
                                       class="btn btn-sm btn-primary"> Edit</a>
                                    <a href="<?php echo e(route('admin.lang.reset', $group->group)); ?>"
                                       class="btn btn-sm btn-warning"> Reset</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>