

<?php $__env->startSection('title', 'Edit ' . $coin->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-3 col-xlg-3 col-md-4">
            <div class="card">
                <div class="card-block">
                    <center><img src="<?php echo e(asset('asset/images/coins/img/'. $coin->logo )); ?>"
                                 class="img-circle" width="200"/>
                        <h4 class="card-title m-t-10"><?php echo e($coin->name); ?></h4>
                        <h6 class="card-subtitle"><?php echo e($coin->symbol); ?></h6>
                        <div class="text-center justify-content-md-center">
                            <a href="<?php echo e(route('home.coin', $coin->symbol)); ?>"
                               class="btn btn-sm btn-rounded btn-secondary"
                               target="_blank"><i class="fa fa-external-link"></i> View <?php echo e($coin->name); ?> Page</a>
                        </div>
                    </center>

                    <small class="text-muted p-t-20 db">Last Updated</small>
                    <h6><?php echo e($coin->last_updated); ?></h6>
                    <small class="text-muted">Website</small>
                    <h6>
                        <?php if(!blank($coin->website)): ?>
                            <a href="<?php echo $coin->website; ?>" target="_blank"><?php echo e(str_limit($coin->website, 32)); ?></a>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </h6>
                    <small class="text-muted">Twitter</small>
                    <h6>
                        <?php if(!blank($coin->twitter)): ?>
                            <a href="https://twitter.com/<?php echo e($coin->twitter); ?>"
                               target="_blank"><?php echo e(str_limit($coin->twitter, 32)); ?></a>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </h6>
                </div>


            </div>
        </div>

        <div class="col-lg-9 col-xlg-9 col-md-6">
            <div class="card">

                <div class="card-block">
                    <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <h4 class="card-title">Edit <?php echo e($coin->name); ?> <sup><?php echo e($coin->symbol); ?></sup> Page Content</h4>

                    <?php echo Form::open(['class'=>'form', 'route' => ['admin.coins.update', $coin->id], 'method' => 'PUT']); ?>

                    <div class="form-group row">
                        <label for="description" class="col-2 col-form-label"><strong>Description</strong></label>
                        <div class="col-12">
                            <?php echo Form::textarea('description', markdown($coin->description), ['id' => 'description', 'rows' => 5, 'class' => 'form-control']); ?>

                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="feature" class="col-2 col-form-label"><strong>Feature</strong></label>
                        <div class="col-12">
                            <?php echo Form::textarea('features', markdown($coin->features), ['id' => 'features', 'rows' => 5, 'class' => 'form-control']); ?>

                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="technology" class="col-2 col-form-label"><strong>Technology</strong></label>
                        <div class="col-12">
                            <?php echo Form::textarea('technology', markdown($coin->technology), ['id' => 'technology', 'rows' => 5, 'class' => 'form-control']); ?>

                        </div>
                    </div>
                    <?php echo Form::submit('Save', ['class' => 'btn btn-lg btn-success']); ?>


                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-styles'); ?>
    <?php echo Html::style('asset/vendor/trumbowyg/ui/trumbowyg.css'); ?>


    <style>
        .form-group {
            margin-bottom: 0 !important;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <?php echo Html::script('asset/vendor/trumbowyg/trumbowyg.js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script>
        (function ($) {
            'use strict';
            var defaultButtons = [
                ['viewHTML'],
                ['formatting'],
                ['strong', 'em'],
                ['link'],
                ['unorderedList', 'orderedList'],
                ['removeformat'],
                ['fullscreen']
            ];

            $('#description').trumbowyg({btns: defaultButtons});
            $('#features').trumbowyg({btns: defaultButtons});
            $('#technology').trumbowyg({btns: defaultButtons});
        })(jQuery);
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>