

<?php $__env->startSection('content'); ?>

    <div class="col-md-8 col-md-offset-2">
        <h2>Contact us
            <small>get in touch with us by filling form below</small>
        </h2>
        <hr class="colorgraph">

        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <?php echo Form::open(['route' => 'contact.store', 'class' => 'contactForm', 'method' => 'POST']); ?>

        <div class="form-group">
            <?php echo Form::label('Your Name'); ?>

            <?php echo Form::text('name', null, ['required', 'class'=>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('Your E-mail Address'); ?>

            <?php echo Form::text('email', null, ['required', 'class'=>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('Your Message'); ?>

            <?php echo Form::textarea('message', null,
                ['required', 'class'=>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::submit('Contact Us!',
              ['class'=>'btn btn-primary btn-lg']); ?>

        </div>
        <?php echo Form::close(); ?>


    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>