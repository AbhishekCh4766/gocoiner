<?php $__env->startSection('title', __('event.page_title')); ?>

<?php $__env->startSection('content'); ?>
<div id="eventoncontent" style="height:100%; width:100%"></div>


</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>