<td class="no-wrap <?php echo e($class); ?>">
    <?php if($value > 0): ?>
        <span class="change-up label label-light-success">
                <i class="fa fa-chevron-up"></i> <?php echo e($value); ?>%</span>
    <?php elseif($value < 0): ?>
        <span class="change-down label label-light-danger">
                <i class="fa fa-chevron-down"></i> <?php echo e($value); ?>%</span>
    <?php endif; ?>
</td>