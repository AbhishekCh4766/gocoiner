

<?php $__env->startSection('title', 'Administration'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-9 col-xlg-10 col-md-8">
            <div class="card">
                <div class="card-block">
                    <h4 class="card-title">Update Profile</h4>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>


                    <?php echo Form::open(['class'=>'form', 'route' => 'admin.profile_update', 'method' => 'POST']); ?>


                    <div class="form-group row<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                        <label for="email" class="col-3 col-form-label">E-Mail Address</label>
                        <div class="col-9">
                            <?php echo Form::text('email', auth()->user()->email, ['class' => 'form-control', 'id' => 'email', 'required' => true]); ?>


                            <?php if($errors->has('email')): ?>
                                <div class="form-control-feedback">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row<?php echo e($errors->has('current_password') ? ' has-danger' : ''); ?>">
                        <label for="current_password" class="col-3 col-form-label">Current Password</label>

                        <div class="col-9">
                            <?php echo Form::password('current_password', ['class' => 'form-control', 'id' => 'current_password', 'required' => true]); ?>


                            <?php if($errors->has('current_password')): ?>
                                <div class="form-control-feedback">
                                    <strong><?php echo e($errors->first('current_password')); ?></strong>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                        <label for="password" class="col-3 col-form-label">New Password</label>

                        <div class="col-9">
                            <?php echo Form::password('password', ['class' => 'form-control', 'id' => 'password', 'required' => true]); ?>


                            <?php if($errors->has('password')): ?>
                                <div class="form-control-feedback">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row<?php echo e($errors->has('password_confirmation') ? ' has-danger' : ''); ?>">
                        <label for="password" class="col-3 col-form-label">Confirm Password</label>

                        <div class="col-9">
                            <?php echo Form::password('password_confirmation', ['class' => 'form-control', 'id' => 'password_confirmation', 'required' => true]); ?>


                            <?php if($errors->has('password_confirmation')): ?>
                                <div class="form-control-feedback">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php echo Form::submit('Update', ['class' => 'btn btn-lg btn-success']); ?>


                    <?php echo Form::close(); ?>



                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>