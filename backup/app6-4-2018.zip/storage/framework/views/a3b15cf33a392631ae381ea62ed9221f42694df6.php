<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <?php echo $__env->make('layouts.includes.meta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->yieldPushContent('before-styles'); ?>
    <link href="<?php echo e(asset('asset/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('asset/css/style.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('asset/css/colors/' . $theme_color . '.min.css')); ?>" id="theme" rel="stylesheet">
    <?php echo $__env->yieldPushContent('after-styles'); ?>
</head>

<body class="fix-header card-no-border">

<div id="main-wrapper">
    <?php echo $__env->make('layouts.includes.header-topbar-starter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="page-wrapper">
        <div class="container-fluid">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    <?php echo $__env->make('layouts.includes.footer-backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

<?php echo $__env->yieldPushContent('before-scripts'); ?>
<script src="<?php echo e(asset('asset/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/vendor/bootstrap/js/tether.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/vendor/sticky-kit-master/sticky-kit.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/js/jquery.slimscroll.js')); ?>"></script>
<script src="<?php echo e(asset('asset/js/sidebarmenu.js')); ?>"></script>
<script src="<?php echo e(asset('asset/js/custom.js')); ?>"></script>
<?php echo $__env->yieldPushContent('after-scripts'); ?>

<?php echo $__env->make('layouts.includes.ga', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldContent('extra-js'); ?>
</body>

</html>