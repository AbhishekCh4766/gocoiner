@extends('layouts.master')

@section('title', __('event.page_title'))

@section('content')
<div id="eventoncontent" style="height:100%; width:100%"></div>




@endsection