<p>You received a message from {{ $app_name }}!</p>

<p>Name: {{ $name }}</p>

<p>Email: {{ $email }}</p>

<p>IP Address: {{ $ip }}</p>

<p>Message:</p>
<p>{{ $user_message }}</p>